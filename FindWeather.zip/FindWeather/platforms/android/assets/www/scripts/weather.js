﻿//var OpenWeatherAppKey = "2c24436d9d9a44bc6d9eae99d7835bb9"; //5bb30b963a0d79993 b96acd6ce552b0c 

/*SEARCH BY USING A CITY NAME (e.g. athens) OR A COMMA-SEPARATED CITY NAME ALONG WITH THE COUNTRY CODE (e.g. athens,gr)*/
const form = document.querySelector(".top-banner form");
const input = document.querySelector(".top-banner input");
const msg = document.querySelector(".top-banner .msg");
const documentList = document.querySelector(".ajax-section .cities"); 
const apiKey = "4d8fb5b93d4af21d66a2948710284366"; 

window.addEventListener("load", () => {
    //event listener za prihvashtane na lokaciq i zarejdane na formite s vremeto na dadenata lokaciq
    let long;
    let lat;
    if (navigator.geolocation) { 
        navigator.geolocation.getCurrentPosition((position) => {
            long = position.coords.longitude; 
            lat = position.coords.latitude; 
            const url = `http://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${long}&appid=${apiKey}&units=metric`;
            fetchUrl(url); 
            msg.textContent = "";
        });
    }
});

form.addEventListener("submit", (e) => {
    //търсене по име на град, ако има еднакви градове в различни страни използваме абревиатурата на страната: Athens,GR или Athens,US
    e.preventDefault();
    let inputVal = input.value;
    let divCities = document.querySelector(".container .cities");
    divCities.innerHTML = "";
    const url = `https://api.openweathermap.org/data/2.5/forecast?q=${inputVal}&appid=4d8fb5b93d4af21d66a2948710284366&units=metric`;
    fetchUrl(url);

    msg.textContent = "";
    form.reset();
    input.focus();
});

function createInnerHTMLForTag(we, icon, city) {
    //създавам html-a на формата
    return `<h2 class="city-name" data-name="${city.name},${city.country}">
          <span>${city.name}</span>
          <sup>${city.country}</sup>
        </h2>
        <h2>
          <span>${we["dt_txt"]}</span>
        </h2>
        <div class="city-temp">${Math.round(we.main.temp)}<sup>C</sup></div>
       `;
}

function timeConverter(UNIX_timestamp) {// функция за превръщане на UNIX времето в обикновена дата
    const a = new Date(Number(UNIX_timestamp) * 1000);
    const months = [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
    ];
    const year = a.getFullYear();
    const month = months[a.getMonth()];
    const date = a.getDate();
    const hour = a.getHours() - 3;
    const min = a.getMinutes();
    const sec = a.getSeconds();
    const day = a.getDay();
    return (time = {
        year,
        month,
        date,
        day: daysOfWeek[day],
        hour,
        min,
        sec,
    });
}

const daysOfWeek = {
    0: "Sunday",
    1: "Monday",
    2: "Tuesday",
    3: "Wednesday",
    4: "Thursday",
    5: "Friday",
    6: "Saturday",
};

function fetchUrl(url) {
    //обработва json-a
    fetch(url)
        .then((response) => response.json())
        .then((data) => {
            const {
                list,
                city, 
            } = data;
            const neededDays = []; // създава масив с необходимите ни данни
            neededDays.push(list[0]); 
            let wantedHour = timeConverter(list[0]["dt"]);  
            for (let i = 1; i < list.length - 1; i++) {
                let currentDateOfRec = timeConverter(list[i]["dt"]);
                if (wantedHour.hour === currentDateOfRec.hour) {
                    neededDays.push(list[i]); 
                }
            }
            for (let i = 0; i < neededDays.length; i++) {
                //създава формите с времето и ги закача към html-a
                const icon = `https://s3-us-west-2.amazonaws.com/s.cdpn.io/162656/${neededDays[i].weather[0]["icon"]}.svg`;
                let li = document.createElement("li");
                li.classList.add("city");
                let a = createInnerHTMLForTag(neededDays[i], icon, city);
                li.innerHTML = a;
                documentList.appendChild(li);
            }
        })
        .catch(() => {
            msg.textContent = "Моля, потърсете валиден град"; // обработва грешки
        });
}
